

const LoadingPage = () => {
  return ( 
    <div className="text-6xl font-extrabold">
        Loading.........
    </div>
   );
}
 
export default LoadingPage;