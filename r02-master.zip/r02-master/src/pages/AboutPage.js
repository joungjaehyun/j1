import BasicLayout from "../layouts/BasicLayout";

const AboutPage = () => {
  return (
    <BasicLayout>
      <div>About Page</div>
    </BasicLayout>
  );
}
 
export default AboutPage;