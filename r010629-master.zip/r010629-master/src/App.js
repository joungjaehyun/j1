import Todo2 from "./components/todo2";





function App() {

  return (
    <div>
       <Todo2></Todo2> 
    </div>
  );
}

export default App;
