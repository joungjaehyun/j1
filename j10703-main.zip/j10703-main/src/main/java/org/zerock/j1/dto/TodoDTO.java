package org.zerock.j1.dto;

import lombok.Data;

@Data
public class TodoDTO {
  
  private Long tno;
  private String title;

}
